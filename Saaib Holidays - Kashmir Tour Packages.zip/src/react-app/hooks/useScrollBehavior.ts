import { useEffect } from 'react';
import { useLocation } from 'react-router';

export function useScrollBehavior() {
  const location = useLocation();
  const isHomePage = location.pathname === '/';

  useEffect(() => {
    // Scroll to top on route change
    window.scrollTo(0, 0);

    // Apply scroll behavior based on page type
    const root = document.documentElement;
    
    if (isHomePage) {
      root.classList.add('home-scroll');
      root.classList.remove('content-scroll');
    } else {
      root.classList.add('content-scroll');
      root.classList.remove('home-scroll');
    }

    return () => {
      root.classList.remove('home-scroll', 'content-scroll');
    };
  }, [isHomePage, location.pathname]);
}
