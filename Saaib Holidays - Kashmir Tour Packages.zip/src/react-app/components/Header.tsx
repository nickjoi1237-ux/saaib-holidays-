import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router';
import { Menu, X, Phone, MessageCircle } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMenuOpen]);

  const isActive = (path: string) => location.pathname === path;

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/about', label: 'About Us' },
    { path: '/owner', label: 'Meet Owner' },
    { path: '/services', label: 'Services' },
    { path: '/packages', label: 'Packages' },
  ];

  return (
    <header className="sticky top-0 z-50 glass-effect shadow-lg">
      {/* Top Bar - Mobile Optimized */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between text-xs sm:text-sm">
            <a 
              href="tel:+917006840041" 
              className="flex items-center gap-1.5 sm:gap-2 hover:text-amber-300 transition-colors font-medium"
            >
              <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline">Call:</span>
              <span>+91 7006840041</span>
            </a>
            <a 
              href="https://wa.me/917006840041"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 sm:gap-2 bg-emerald-600 hover:bg-emerald-700 px-2 sm:px-3 py-1 rounded-full transition-colors font-medium"
            >
              <MessageCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span>WhatsApp Us</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo - Mobile Optimized */}
          <Link to="/" className="flex items-center gap-2 sm:gap-3 group">
            <img 
              src="https://mocha-cdn.com/019ad43a-3952-7b8d-b3c5-14ab68e815f2/453787518_1001561351978709_6982885789991276894_n.jpg" 
              alt="Saaib Holidays" 
              className="h-10 w-10 sm:h-12 sm:w-12 rounded-full shadow-md group-hover:shadow-xl transition-all group-hover:scale-110 transform"
            />
            <div className="flex flex-col">
              <span className="text-lg sm:text-2xl font-bold text-gradient">Saaib Holidays</span>
              <span className="text-[10px] sm:text-xs text-gray-600 hidden sm:block">Explore Kashmir with Us</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-medium transition-colors relative group ${
                  isActive(link.path)
                    ? 'text-blue-800'
                    : 'text-gray-700 hover:text-blue-700'
                }`}
              >
                {link.label}
                <span className={`absolute -bottom-1 left-0 w-full h-0.5 bg-gradient-to-r from-blue-800 to-emerald-600 transform origin-left transition-transform ${
                  isActive(link.path) ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
                }`} />
              </Link>
            ))}
            <a 
              href="tel:+917006840041" 
              className="btn-primary text-sm"
            >
              Call Now
            </a>
          </nav>

          {/* Mobile CTA + Menu */}
          <div className="flex items-center gap-2 lg:hidden">
            <a 
              href="tel:+917006840041" 
              className="btn-primary text-xs sm:text-sm px-3 sm:px-4 py-2"
            >
              Call
            </a>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors relative z-[60]"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? (
                <X className="w-5 h-5 sm:w-6 sm:h-6 text-gray-700" />
              ) : (
                <Menu className="w-5 h-5 sm:w-6 sm:h-6 text-gray-700" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation - Fixed Overlay with Independent Scroll */}
        {isMenuOpen && (
          <>
            {/* Backdrop */}
            <div 
              className="lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-40 animate-in fade-in duration-300"
              onClick={() => setIsMenuOpen(false)}
              style={{ top: '0' }}
            />
            
            {/* Menu Panel */}
            <nav className="lg:hidden fixed left-0 right-0 bg-white z-50 overflow-y-auto animate-in slide-in-from-top duration-300 shadow-2xl" style={{ top: '120px', maxHeight: 'calc(100vh - 120px)' }}>
              <div className="p-4 pb-8">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setIsMenuOpen(false)}
                    className={`block py-3 px-4 font-medium transition-colors rounded-lg my-1 ${
                      isActive(link.path)
                        ? 'text-blue-800 bg-blue-50'
                        : 'text-gray-700 hover:text-blue-700 hover:bg-gray-50'
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
                <div className="px-4 mt-6 space-y-3">
                  <a
                    href="tel:+917006840041"
                    className="block text-center btn-secondary text-sm"
                  >
                    <Phone className="w-4 h-4 inline mr-2" />
                    Call Now
                  </a>
                  <a
                    href="https://wa.me/917006840041"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-center bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-4 py-3 rounded-xl font-semibold transition-all text-sm"
                  >
                    <MessageCircle className="w-4 h-4 inline mr-2" />
                    WhatsApp Us
                  </a>
                </div>
              </div>
            </nav>
          </>
        )}
      </div>
    </header>
  );
}
