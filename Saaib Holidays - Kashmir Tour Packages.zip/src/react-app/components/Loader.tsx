import { useEffect, useState } from 'react';

export default function Loader() {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Prevent scrolling while loader is visible
    document.body.style.overflow = 'hidden';
    
    // Hide loader after 2 seconds with fade out
    const timer = setTimeout(() => {
      setIsVisible(false);
      document.body.style.overflow = 'unset';
    }, 2000);

    return () => {
      clearTimeout(timer);
      document.body.style.overflow = 'unset';
    };
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-gradient-to-br from-blue-950 via-blue-900 to-emerald-950 flex items-center justify-center animate-out fade-out duration-500">
      {/* Animated Background Shapes */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-blue-700/20 rounded-full -top-48 -right-48 floating" />
        <div className="shape-3d w-80 h-80 bg-emerald-600/20 rounded-full -bottom-40 -left-40 floating" style={{ animationDelay: '1s' }} />
        <div className="shape-3d w-64 h-64 bg-amber-500/10 rounded-full top-1/4 left-1/4 floating" style={{ animationDelay: '2s' }} />
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center">
        {/* Logo */}
        <div className="mb-6 animate-in zoom-in duration-700">
          <img 
            src="https://mocha-cdn.com/019ad43a-3952-7b8d-b3c5-14ab68e815f2/453787518_1001561351978709_6982885789991276894_n.jpg" 
            alt="Saaib Holidays" 
            className="w-20 h-20 sm:w-24 sm:h-24 rounded-full mx-auto shadow-2xl border-4 border-white/20"
          />
        </div>

        {/* Brand Name */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-2 animate-in slide-in-from-bottom duration-700 delay-200">
          Saaib Holidays
        </h1>
        <p className="text-blue-200 text-sm sm:text-base mb-8 animate-in slide-in-from-bottom duration-700 delay-300">
          Your Kashmir Travel Experts
        </p>

        {/* Animated Shikara Boat */}
        <div className="relative w-64 sm:w-80 mx-auto h-20 mb-4 animate-in fade-in duration-1000 delay-500">
          {/* Water waves */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-blue-400/50 to-transparent animate-pulse" />
          <div className="absolute bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-blue-300/30 to-transparent animate-pulse" style={{ animationDelay: '0.5s' }} />
          
          {/* Shikara boat moving across */}
          <div className="absolute top-1/2 left-0 transform -translate-y-1/2 animate-shikara">
            <svg className="w-12 h-12 sm:w-16 sm:h-16 text-amber-400" viewBox="0 0 64 64" fill="currentColor">
              {/* Boat body */}
              <path d="M8 32 L8 36 Q8 38 10 38 L54 38 Q56 38 56 36 L56 32 Z" />
              {/* Boat top */}
              <path d="M12 28 L12 32 L52 32 L52 28 Q52 26 50 26 L14 26 Q12 26 12 28 Z" />
              {/* Canopy */}
              <ellipse cx="32" cy="22" rx="16" ry="6" opacity="0.7" />
              <rect x="16" y="20" width="32" height="8" rx="2" opacity="0.8" />
            </svg>
          </div>
        </div>

        {/* Loading Text */}
        <div className="text-white/80 text-sm sm:text-base font-medium animate-pulse">
          Loading your Kashmir experience...
        </div>
      </div>

      <style>{`
        @keyframes shikara {
          0% {
            left: -10%;
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 1;
          }
          100% {
            left: 110%;
            opacity: 0;
          }
        }
        
        .animate-shikara {
          animation: shikara 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
