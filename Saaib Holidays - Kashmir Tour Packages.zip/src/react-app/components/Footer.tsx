import { Link } from 'react-router';
import { MapPin, Phone, Mail, Instagram, MessageCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative bg-gradient-to-b from-gray-900 via-blue-950 to-gray-950 text-white overflow-hidden">
      {/* 3D Background Shapes */}
      <div className="shape-3d w-96 h-96 bg-blue-700 rounded-full -top-48 -left-48" />
      <div className="shape-3d w-80 h-80 bg-emerald-600 rounded-full -bottom-40 -right-40" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
          {/* Company Info */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <img 
                src="https://mocha-cdn.com/019ad43a-3952-7b8d-b3c5-14ab68e815f2/453787518_1001561351978709_6982885789991276894_n.jpg" 
                alt="Saaib Holidays" 
                className="h-12 w-12 rounded-full shadow-lg"
              />
              <div>
                <h3 className="text-xl font-bold">Saaib Holidays</h3>
                <p className="text-sm text-gray-400">Kashmir Travel Experts</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">
              Your trusted partner for unforgettable Kashmir experiences. Creating memories since 2013.
            </p>
            <div className="flex gap-3">
              <a 
                href="https://instagram.com/saaibholidays" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="p-2.5 bg-gradient-to-r from-pink-600 to-purple-600 rounded-lg hover:shadow-lg hover:scale-110 transition-all"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a 
                href="https://wa.me/917006840041" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="p-2.5 bg-gradient-to-r from-green-600 to-green-700 rounded-lg hover:shadow-lg hover:scale-110 transition-all"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-gradient">Quick Links</h4>
            <ul className="space-y-2">
              {[
                { to: '/', label: 'Home' },
                { to: '/about', label: 'About Us' },
                { to: '/owner', label: 'Meet Owner' },
                { to: '/services', label: 'Services' },
                { to: '/packages', label: 'Packages' }
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-gray-400 hover:text-amber-400 transition-colors text-sm block">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Popular Destinations */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-gradient">Destinations</h4>
            <ul className="space-y-2">
              {[
                { slug: 'srinagar', name: 'Srinagar' },
                { slug: 'gulmarg', name: 'Gulmarg' },
                { slug: 'pahalgam', name: 'Pahalgam' },
                { slug: 'sonmarg', name: 'Sonmarg' },
                { slug: 'leh-ladakh', name: 'Leh Ladakh' }
              ].map((dest) => (
                <li key={dest.slug}>
                  <Link to={`/destination/${dest.slug}`} className="text-gray-400 hover:text-amber-400 transition-colors text-sm block">
                    {dest.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-gradient">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-gray-400 text-sm">
                <MapPin className="w-4 h-4 flex-shrink-0 text-emerald-500 mt-0.5" />
                <span className="leading-snug">Room No. 208, 1st Floor, Yatri Bhawan – 2, Srinagar</span>
              </li>
              <li>
                <a 
                  href="tel:+917006840041" 
                  className="flex items-center gap-2 text-gray-400 hover:text-amber-400 transition-colors text-sm"
                >
                  <Phone className="w-4 h-4 text-blue-500" />
                  <span>+91 7006840041</span>
                </a>
              </li>
              <li>
                <a 
                  href="mailto:saaibholidays@gmail.com" 
                  className="flex items-center gap-2 text-gray-400 hover:text-amber-400 transition-colors text-sm break-all"
                >
                  <Mail className="w-4 h-4 text-blue-500 flex-shrink-0" />
                  <span>saaibholidays@gmail.com</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Trust Indicators - Mobile Optimized */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mt-12 pt-8 border-t border-gray-800">
          {[
            { number: '10+', label: 'Years Experience' },
            { number: '5000+', label: 'Happy Travelers' },
            { number: '24/7', label: 'Support' },
            { number: '100%', label: 'Satisfaction' }
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-gradient">{stat.number}</div>
              <div className="text-xs sm:text-sm text-gray-400 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-gray-800 text-center">
          <p className="text-gray-400 text-xs sm:text-sm">
            &copy; {new Date().getFullYear()} Saaib Holidays. All rights reserved.
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Certified Local Guides | Safe & Secure Travel | 24/7 Support
          </p>
        </div>
      </div>
    </footer>
  );
}
