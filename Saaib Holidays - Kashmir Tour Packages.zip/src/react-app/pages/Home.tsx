import { Link } from 'react-router';
import { MapPin, Users, Mountain, Shield, Clock, Award, Star, Phone, MessageCircle, Calendar } from 'lucide-react';

export default function Home() {
  const destinations = [
    {
      name: 'Srinagar',
      description: 'Dal Lake, Mughal Gardens & Houseboats',
      slug: 'srinagar',
      gradient: 'from-blue-600 to-blue-800'
    },
    {
      name: 'Gulmarg',
      description: 'Asia\'s Highest Cable Car & Skiing',
      slug: 'gulmarg',
      gradient: 'from-emerald-600 to-emerald-800'
    },
    {
      name: 'Pahalgam',
      description: 'Valley of Shepherds & Trekking',
      slug: 'pahalgam',
      gradient: 'from-blue-700 to-emerald-700'
    },
    {
      name: 'Sonmarg',
      description: 'Meadow of Gold & Glaciers',
      slug: 'sonmarg',
      gradient: 'from-amber-600 to-orange-700'
    },
    {
      name: 'Leh Ladakh',
      description: 'High Altitude Desert Adventure',
      slug: 'leh-ladakh',
      gradient: 'from-purple-600 to-blue-800'
    },
    {
      name: 'Doodhpathri',
      description: 'Valley of Milk & Meadows',
      slug: 'doodhpathri',
      gradient: 'from-green-600 to-emerald-700'
    }
  ];

  const services = [
    {
      icon: Users,
      title: 'Family Packages',
      description: 'Customized family-friendly tours with comfortable stays'
    },
    {
      icon: Mountain,
      title: 'Adventure Tours',
      description: 'Trekking, skiing, rafting and snow activities'
    },
    {
      icon: Shield,
      title: 'Safe & Secure',
      description: '24/7 support with certified local guides'
    }
  ];

  const testimonials = [
    {
      name: 'Rajesh Kumar',
      location: 'Delhi',
      rating: 5,
      text: 'Amazing experience! Saaib Holidays made our Kashmir trip memorable. Professional service and beautiful locations.'
    },
    {
      name: 'Priya Sharma',
      location: 'Mumbai',
      rating: 5,
      text: 'Perfect honeymoon package. Everything was well organized from airport pickup to hotel stays. Highly recommended!'
    },
    {
      name: 'Amit Patel',
      location: 'Bangalore',
      rating: 5,
      text: 'Great value for money. The team was very helpful and accommodating. Will definitely book again!'
    }
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section with 3D Elements */}
      <section className="relative min-h-[85vh] sm:min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* 3D Background Shapes */}
        <div className="shape-3d w-96 h-96 bg-blue-700 rounded-full -top-48 -right-48 floating" />
        <div className="shape-3d w-80 h-80 bg-emerald-600 rounded-full -bottom-40 -left-40 floating" style={{ animationDelay: '2s' }} />
        <div className="shape-3d w-64 h-64 bg-amber-500 rounded-full top-1/4 right-1/4 floating" style={{ animationDelay: '4s' }} />
        
        <div className="absolute inset-0 bg-gradient-to-br from-blue-950/95 via-blue-900/90 to-emerald-950/95 z-10" />
        <img 
          src="https://mocha-cdn.com/019ad43a-3952-7b8d-b3c5-14ab68e815f2/hero-kashmir.png"
          alt="Kashmir Valley"
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        <div className="relative z-20 text-center text-white max-w-5xl mx-auto px-4">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-4 sm:mb-6 drop-shadow-2xl leading-tight">
            Discover the Paradise
            <span className="block text-amber-400 mt-2">on Earth</span>
          </h1>
          <p className="text-base sm:text-xl md:text-2xl mb-6 sm:mb-8 text-gray-100 drop-shadow-lg max-w-3xl mx-auto">
            Experience Kashmir's breathtaking beauty with customized tour packages
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center max-w-lg mx-auto">
            <a 
              href="tel:+917006840041" 
              className="w-full sm:w-auto btn-primary text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-4 flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Call Now
            </a>
            <a 
              href="https://wa.me/917006840041"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg transition-all shadow-lg hover:shadow-2xl hover:-translate-y-1 transform flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              WhatsApp Us
            </a>
          </div>
          
          <p className="mt-4 sm:mt-6 text-sm sm:text-base text-gray-300">
            <Clock className="w-4 h-4 inline mr-1" />
            24/7 Support Available
          </p>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-6 sm:py-8 bg-gradient-to-r from-blue-800 via-blue-700 to-emerald-700">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 text-white text-center">
            {[
              { icon: Award, text: 'Certified Guides' },
              { icon: Shield, text: 'Safe & Secure' },
              { icon: Clock, text: '24/7 Support' },
              { icon: Users, text: '5000+ Travelers' }
            ].map((item, index) => (
              <div key={index} className="flex flex-col items-center gap-2 p-3 sm:p-4 glass-effect rounded-xl">
                <item.icon className="w-6 h-6 sm:w-8 sm:h-8" />
                <div className="font-semibold text-xs sm:text-sm">{item.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section with 3D Cards */}
      <section className="py-12 sm:py-20 bg-gradient-to-b from-gray-50 to-white relative">
        <div className="shape-3d w-72 h-72 bg-blue-600 rounded-full top-0 right-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Our Services</h2>
            <p className="text-gray-600 text-sm sm:text-lg">Complete travel solutions for your Kashmir journey</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {services.map((service, index) => (
              <div key={index} className="glass-effect p-6 sm:p-8 rounded-2xl shadow-lg card-3d">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-xl flex items-center justify-center mb-4 sm:mb-6 transform hover:rotate-12 transition-transform">
                  <service.icon className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3 text-gray-800">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed text-sm sm:text-base">{service.description}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-8 sm:mt-12">
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
              <Link to="/services" className="btn-outline">
                View All Services
              </Link>
              <a 
                href="tel:+917006840041"
                className="btn-primary flex items-center justify-center gap-2"
              >
                <Phone className="w-5 h-5" />
                Call for Booking
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Destinations Section */}
      <section className="py-12 sm:py-20 relative">
        <div className="shape-3d w-96 h-96 bg-emerald-600 rounded-full -bottom-48 -left-48" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Popular Destinations</h2>
            <p className="text-gray-600 text-sm sm:text-lg">Explore the most beautiful places in Kashmir</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {destinations.map((destination, index) => (
              <Link 
                key={index}
                to={`/destination/${destination.slug}`}
                className="group relative h-64 sm:h-72 lg:h-80 rounded-2xl overflow-hidden shadow-xl card-3d glass-effect"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${destination.gradient} opacity-90 group-hover:opacity-95 transition-opacity`} />
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-4 sm:p-6">
                  <MapPin className="w-10 h-10 sm:w-12 sm:h-12 mb-3 sm:mb-4 text-white/80 group-hover:scale-110 transition-transform" />
                  <h3 className="text-2xl sm:text-3xl font-bold mb-2">{destination.name}</h3>
                  <p className="text-sm sm:text-base text-white/90 text-center">{destination.description}</p>
                  <div className="mt-4 px-4 sm:px-6 py-2 bg-white/20 backdrop-blur-sm rounded-full text-xs sm:text-sm font-semibold">
                    Explore →
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-12 sm:py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">What Our Travelers Say</h2>
            <p className="text-gray-600 text-sm sm:text-lg">Real experiences from our happy customers</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="glass-effect p-6 sm:p-8 rounded-2xl shadow-lg card-3d">
                <div className="flex gap-1 mb-3 sm:mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 sm:mb-6 italic leading-relaxed text-sm sm:text-base">"{testimonial.text}"</p>
                <div>
                  <div className="font-semibold text-gray-800">{testimonial.name}</div>
                  <div className="text-xs sm:text-sm text-gray-500">{testimonial.location}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 sm:py-20 bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white relative overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-amber-500 rounded-full top-0 right-0" />
        <div className="shape-3d w-80 h-80 bg-blue-700 rounded-full bottom-0 left-0" />
        
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <Calendar className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 sm:mb-6" />
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">Ready to Explore Kashmir?</h2>
          <p className="text-lg sm:text-xl mb-6 sm:mb-8 text-blue-100">
            Let us create a perfect itinerary tailored just for you
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center max-w-2xl mx-auto">
            <a 
              href="https://wa.me/917006840041"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto bg-white text-blue-800 px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg hover:bg-gray-100 transition-all shadow-xl hover:shadow-2xl hover:-translate-y-1 transform flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              Chat on WhatsApp
            </a>
            <a 
              href="tel:+917006840041" 
              className="w-full sm:w-auto bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg transition-all shadow-xl hover:shadow-2xl hover:-translate-y-1 transform flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Call: +91 7006840041
            </a>
          </div>
          
          <p className="mt-4 sm:mt-6 text-sm sm:text-base text-blue-200">
            Available 24/7 | Free Consultation | No Booking Required to Inquire
          </p>
        </div>
      </section>
    </div>
  );
}
