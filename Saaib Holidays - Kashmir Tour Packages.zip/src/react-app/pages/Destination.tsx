import { useParams } from 'react-router';
import { Calendar, MapPin, Clock, Sun, Snowflake, Mountain, Camera, Utensils, Hotel, Phone, MessageCircle } from 'lucide-react';

export default function Destination() {
  const { slug } = useParams<{ slug: string }>();

  const destinations: Record<string, {
    name: string;
    tagline: string;
    description: string;
    bestTime: string;
    altitude: string;
    distance: string;
    highlights: string[];
    activities: { icon: React.ComponentType<{ className?: string }>; name: string; description: string; }[];
    itinerary: { day: number; title: string; activities: string[]; }[];
    pricing: { duration: string; price: string; includes: string[]; }[];
    gradient: string;
  }> = {
    'srinagar': {
      name: 'Srinagar',
      tagline: 'The Venice of the East',
      description: 'Srinagar, the summer capital of Jammu & Kashmir, is famous for its serene Dal Lake, magnificent Mughal Gardens, and traditional houseboats. The city offers a perfect blend of natural beauty, rich culture, and warm hospitality.',
      bestTime: 'March to October',
      altitude: '1,585 meters',
      distance: '15 km from Airport',
      highlights: ['Dal Lake Shikara Ride', 'Mughal Gardens', 'Houseboat Stay', 'Floating Market', 'Hazratbal Shrine', 'Pari Mahal'],
      activities: [
        { icon: Camera, name: 'Photography', description: 'Capture stunning landscapes' },
        { icon: Mountain, name: 'Shikara Rides', description: 'Explore Dal Lake in traditional boats' },
        { icon: Utensils, name: 'Wazwan Cuisine', description: 'Authentic Kashmiri multi-course meal' },
        { icon: Hotel, name: 'Houseboat Stay', description: 'Unique accommodation on Dal Lake' }
      ],
      itinerary: [
        { day: 1, title: 'Arrival & Dal Lake', activities: ['Airport pickup', 'Check-in to hotel/houseboat', 'Evening Shikara ride', 'Visit floating market'] },
        { day: 2, title: 'Mughal Gardens', activities: ['Visit Nishat Bagh', 'Explore Shalimar Bagh', 'Chashme Shahi Garden', 'Pari Mahal viewpoint'] },
        { day: 3, title: 'Local Sightseeing', activities: ['Hazratbal Shrine', 'Shankaracharya Temple', 'Local market shopping', 'Handicraft centers'] }
      ],
      pricing: [
        { duration: '3 Days / 2 Nights', price: '₹9,999', includes: ['Hotel accommodation', 'Breakfast & dinner', 'Shikara ride', 'Local sightseeing'] },
        { duration: '5 Days / 4 Nights', price: '₹15,999', includes: ['Houseboat + hotel', 'All meals', 'Airport transfers', 'Complete city tour'] }
      ],
      gradient: 'from-blue-700 to-blue-900'
    },
    'gulmarg': {
      name: 'Gulmarg',
      tagline: 'The Meadow of Flowers',
      description: 'Gulmarg is a pristine hill station known for having Asia\'s highest cable car, world-class skiing, and breathtaking mountain views. In winter, it transforms into a snow wonderland, while summer brings lush green meadows.',
      bestTime: 'Dec-Mar (Snow), Apr-Jun (Meadows)',
      altitude: '2,650 meters',
      distance: '50 km from Srinagar',
      highlights: ['Gulmarg Gondola', 'Skiing & Snowboarding', 'Apharwat Peak', 'Golf Course', 'Snow Activities', 'Mountain Trekking'],
      activities: [
        { icon: Snowflake, name: 'Skiing', description: 'World-class skiing on pristine slopes' },
        { icon: Mountain, name: 'Gondola Ride', description: 'Asia\'s highest cable car' },
        { icon: Camera, name: 'Photography', description: 'Stunning Himalayan panoramas' },
        { icon: Sun, name: 'Meadow Walks', description: 'Scenic walks through meadows' }
      ],
      itinerary: [
        { day: 1, title: 'Gulmarg Adventure', activities: ['Drive from Srinagar', 'Gondola to Apharwat', 'Snow activities', 'Explore meadows'] },
        { day: 2, title: 'Skiing & Activities', activities: ['Skiing lessons', 'Snowboarding', 'Snow trekking', 'Photography'] }
      ],
      pricing: [
        { duration: '2 Days / 1 Night', price: '₹7,999', includes: ['Hotel stay', 'Meals', 'Gondola tickets', 'Snow activities'] },
        { duration: '4 Days / 3 Nights', price: '₹18,999', includes: ['Deluxe accommodation', 'All meals', 'Skiing equipment', 'Instructors'] }
      ],
      gradient: 'from-emerald-600 to-emerald-900'
    },
    'pahalgam': {
      name: 'Pahalgam',
      tagline: 'Valley of Shepherds',
      description: 'Pahalgam is a picturesque town surrounded by snow-capped mountains, dense pine forests, and the Lidder River. It serves as the base camp for Amarnath Yatra and offers numerous trekking opportunities.',
      bestTime: 'April to November',
      altitude: '2,740 meters',
      distance: '95 km from Srinagar',
      highlights: ['Betaab Valley', 'Aru Valley', 'Chandanwari', 'Lidder River', 'Baisaran Meadows', 'Kolahoi Glacier'],
      activities: [
        { icon: Mountain, name: 'Trekking', description: 'Trails for all difficulty levels' },
        { icon: Camera, name: 'Valley Tours', description: 'Visit Betaab, Aru, Baisaran valleys' },
        { icon: Sun, name: 'River Rafting', description: 'Rafting on Lidder River' },
        { icon: Hotel, name: 'Camping', description: 'Overnight camping in meadows' }
      ],
      itinerary: [
        { day: 1, title: 'Pahalgam Arrival', activities: ['Drive from Srinagar', 'Betaab Valley', 'Lidder River walk', 'Hotel check-in'] },
        { day: 2, title: 'Valley Exploration', activities: ['Aru Valley trek', 'Baisaran meadows', 'Horse riding', 'Local market'] },
        { day: 3, title: 'Chandanwari Trip', activities: ['Chandanwari excursion', 'Snow activities', 'Photography', 'Return'] }
      ],
      pricing: [
        { duration: '3 Days / 2 Nights', price: '₹11,999', includes: ['Hotel accommodation', 'Meals', 'Valley tours', 'Transport'] },
        { duration: '5 Days / 4 Nights', price: '₹19,999', includes: ['Premium hotels', 'All meals', 'Trekking gear', 'Guide'] }
      ],
      gradient: 'from-blue-700 to-emerald-700'
    },
    'sonmarg': {
      name: 'Sonmarg',
      tagline: 'The Meadow of Gold',
      description: 'Sonmarg is a spectacular mountain valley known for its glaciers, alpine meadows, and the gateway to Ladakh. The Thajiwas Glacier and pristine landscapes make it a photographer\'s paradise.',
      bestTime: 'May to October',
      altitude: '2,800 meters',
      distance: '80 km from Srinagar',
      highlights: ['Thajiwas Glacier', 'Zoji La Pass', 'Nilagrad River', 'Alpine Meadows', 'Pony Rides', 'Camping Sites'],
      activities: [
        { icon: Snowflake, name: 'Glacier Visit', description: 'Trek to Thajiwas Glacier' },
        { icon: Mountain, name: 'Trekking', description: 'High-altitude trails' },
        { icon: Camera, name: 'Photography', description: 'Golden meadows and glaciers' },
        { icon: Sun, name: 'Pony Rides', description: 'Traditional pony rides' }
      ],
      itinerary: [
        { day: 1, title: 'Sonmarg Experience', activities: ['Drive from Srinagar', 'Thajiwas Glacier', 'Pony rides', 'Nilagrad River'] },
        { day: 2, title: 'Exploration', activities: ['Alpine walks', 'Local market', 'Photography', 'Return'] }
      ],
      pricing: [
        { duration: '2 Days / 1 Night', price: '₹8,999', includes: ['Hotel stay', 'Meals', 'Glacier visit', 'Transportation'] }
      ],
      gradient: 'from-amber-600 to-orange-700'
    },
    'leh-ladakh': {
      name: 'Leh Ladakh',
      tagline: 'Land of High Passes',
      description: 'Ladakh is a high-altitude desert offering dramatic landscapes, ancient monasteries, and adventure opportunities. From Pangong Lake to Nubra Valley, it\'s an experience unlike any other.',
      bestTime: 'May to September',
      altitude: '3,500 meters',
      distance: '434 km from Srinagar',
      highlights: ['Pangong Lake', 'Nubra Valley', 'Khardung La Pass', 'Magnetic Hill', 'Buddhist Monasteries', 'Double-humped Camels'],
      activities: [
        { icon: Mountain, name: 'High-altitude Trek', description: 'Trek through mountain passes' },
        { icon: Camera, name: 'Lake Photography', description: 'Stunning Pangong Lake' },
        { icon: Sun, name: 'Desert Safari', description: 'Camel rides in Nubra' },
        { icon: Hotel, name: 'Camping', description: 'Camp by Pangong Lake' }
      ],
      itinerary: [
        { day: 1, title: 'Leh Arrival', activities: ['Flight to Leh', 'Acclimatization', 'Leh market', 'Local sightseeing'] },
        { day: 2, title: 'Monasteries', activities: ['Shey Palace', 'Thiksey Monastery', 'Hemis Monastery', 'Stok Palace'] },
        { day: 3, title: 'Pangong Lake', activities: ['Drive to Pangong', 'Lake exploration', 'Photography', 'Camping'] },
        { day: 4, title: 'Nubra Valley', activities: ['Khardung La', 'Nubra Valley', 'Camel safari', 'Sand dunes'] }
      ],
      pricing: [
        { duration: '6 Days / 5 Nights', price: '₹28,999', includes: ['Hotels & camps', 'All meals', 'SUV transport', 'Permits'] },
        { duration: '10 Days / 9 Nights', price: '₹42,999', includes: ['Premium stay', 'All meals', 'Complete tour', 'Oxygen support'] }
      ],
      gradient: 'from-purple-600 to-blue-900'
    },
    'doodhpathri': {
      name: 'Doodhpathri',
      tagline: 'Valley of Milk',
      description: 'Doodhpathri is a lesser-known gem with lush green meadows, crystal clear streams, and pine forests. Its name comes from the milky white water of its streams.',
      bestTime: 'April to November',
      altitude: '2,730 meters',
      distance: '42 km from Srinagar',
      highlights: ['Green Meadows', 'Crystal Streams', 'Pine Forests', 'Pony Rides', 'Peaceful Environment', 'Picnic Spots'],
      activities: [
        { icon: Sun, name: 'Meadow Walks', description: 'Peaceful walks through valleys' },
        { icon: Camera, name: 'Photography', description: 'Pristine landscapes' },
        { icon: Mountain, name: 'Pony Rides', description: 'Traditional pony rides' },
        { icon: Utensils, name: 'Picnics', description: 'Perfect for family picnics' }
      ],
      itinerary: [
        { day: 1, title: 'Doodhpathri Day Trip', activities: ['Morning drive', 'Meadow exploration', 'Stream walks', 'Return evening'] }
      ],
      pricing: [
        { duration: '1 Day Trip', price: '₹3,999', includes: ['Transportation', 'Guide', 'Lunch', 'Entry fees'] }
      ],
      gradient: 'from-green-600 to-emerald-800'
    }
  };

  const destination = destinations[slug || ''] || destinations['srinagar'];

  return (
    <div className="overflow-hidden">
      {/* Hero Section with Enhanced 3D Elements */}
      <section className={`relative min-h-[60vh] sm:min-h-[70vh] flex items-center justify-center overflow-hidden bg-gradient-to-br ${destination.gradient}`}>
        {/* Animated 3D Shapes */}
        <div className="shape-3d w-96 h-96 bg-white/10 rounded-full -top-48 -right-48 floating" />
        <div className="shape-3d w-80 h-80 bg-white/10 rounded-full -bottom-40 -left-40 floating" style={{ animationDelay: '2s' }} />
        <div className="shape-3d w-64 h-64 bg-white/5 rounded-full top-1/4 left-1/4 floating" style={{ animationDelay: '4s' }} />
        <div className="shape-3d w-72 h-72 bg-white/5 rounded-full bottom-1/3 right-1/3 floating" style={{ animationDelay: '6s' }} />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-black/20" />
        
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <div className="mb-6">
            <MapPin className="w-12 h-12 sm:w-16 sm:h-16 mx-auto text-white/80 animate-bounce" />
          </div>
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold mb-3 sm:mb-4 drop-shadow-2xl animate-in slide-in-from-bottom duration-700">{destination.name}</h1>
          <p className="text-xl sm:text-2xl md:text-3xl text-gray-100 font-light drop-shadow-lg animate-in slide-in-from-bottom duration-1000">{destination.tagline}</p>
        </div>
      </section>

      {/* Quick Info */}
      <section className="py-6 sm:py-8 bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 text-center">
            {[
              { icon: Calendar, label: 'Best Time', value: destination.bestTime },
              { icon: Mountain, label: 'Altitude', value: destination.altitude },
              { icon: MapPin, label: 'Distance', value: destination.distance },
              { icon: Clock, label: 'Recommended', value: '2-3 Days' }
            ].map((item, index) => (
              <div key={index} className="glass-effect p-3 sm:p-4 rounded-xl">
                <item.icon className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-2" />
                <div className="text-xs sm:text-sm text-blue-100">{item.label}</div>
                <div className="font-semibold text-xs sm:text-base mt-1">{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Description */}
      <section className="py-12 sm:py-20 relative">
        <div className="shape-3d w-72 h-72 bg-blue-600 rounded-full top-0 right-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4 sm:mb-6 text-gradient">About {destination.name}</h2>
            <p className="text-gray-700 text-base sm:text-lg leading-relaxed">{destination.description}</p>
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="py-12 sm:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl sm:text-4xl font-bold mb-8 sm:mb-12 text-center text-gradient">Top Attractions</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
            {destination.highlights.map((highlight, index) => (
              <div key={index} className="glass-effect p-4 sm:p-6 rounded-xl shadow-md text-center card-3d">
                <MapPin className="w-6 h-6 sm:w-8 sm:h-8 text-blue-700 mx-auto mb-2 sm:mb-3" />
                <h3 className="font-semibold text-gray-800 text-sm sm:text-base">{highlight}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Activities */}
      <section className="py-12 sm:py-20 relative">
        <div className="shape-3d w-80 h-80 bg-emerald-600 rounded-full bottom-0 left-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <h2 className="text-3xl sm:text-4xl font-bold mb-8 sm:mb-12 text-center text-gradient">Things To Do</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
            {destination.activities.map((activity, index) => (
              <div key={index} className="glass-effect p-4 sm:p-6 rounded-xl shadow-lg text-center card-3d">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 transform hover:rotate-12 transition-transform">
                  <activity.icon className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold mb-2 text-gray-800">{activity.name}</h3>
                <p className="text-gray-600 text-xs sm:text-sm">{activity.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sample Itinerary */}
      <section className="py-12 sm:py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl sm:text-4xl font-bold mb-8 sm:mb-12 text-center text-gradient">Sample Itinerary</h2>
          <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6">
            {destination.itinerary.map((day, index) => (
              <div key={index} className="glass-effect p-4 sm:p-6 lg:p-8 rounded-xl shadow-lg card-3d">
                <div className="flex items-start gap-3 sm:gap-4">
                  <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-blue-700 to-emerald-700 rounded-full flex items-center justify-center text-white font-bold text-lg sm:text-xl flex-shrink-0">
                    {day.day}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3 text-gray-800">{day.title}</h3>
                    <ul className="space-y-1.5 sm:space-y-2">
                      {day.activities.map((activity, i) => (
                        <li key={i} className="flex items-center gap-2 text-gray-700 text-sm sm:text-base">
                          <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-gradient-to-r from-blue-700 to-emerald-600 rounded-full flex-shrink-0" />
                          <span>{activity}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-12 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl sm:text-4xl font-bold mb-8 sm:mb-12 text-center text-gradient">Tour Packages</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {destination.pricing.map((pkg, index) => (
              <div key={index} className="glass-effect rounded-2xl shadow-xl overflow-hidden card-3d">
                <div className={`bg-gradient-to-r ${destination.gradient} text-white p-4 sm:p-6 text-center`}>
                  <div className="text-xs sm:text-sm font-medium mb-2">{pkg.duration}</div>
                  <div className="text-3xl sm:text-4xl font-bold">{pkg.price}</div>
                  <div className="text-xs sm:text-sm text-blue-100 mt-1">per person</div>
                </div>
                <div className="p-4 sm:p-6">
                  <h3 className="font-semibold text-gray-800 mb-3 sm:mb-4 text-sm sm:text-base">Package Includes:</h3>
                  <ul className="space-y-2 mb-4 sm:mb-6">
                    {pkg.includes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-gray-700 text-xs sm:text-sm">
                        <div className="w-1.5 h-1.5 bg-gradient-to-r from-blue-700 to-emerald-600 rounded-full flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                  <a 
                    href="https://wa.me/917006840041"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full bg-gradient-to-r from-blue-700 to-emerald-700 text-white py-2.5 sm:py-3 rounded-lg font-semibold text-center hover:from-blue-800 hover:to-emerald-800 transition-all text-sm sm:text-base"
                  >
                    Book on WhatsApp
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 sm:py-20 bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white relative overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-amber-500 rounded-full top-0 right-0" />
        
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 sm:mb-6">Ready to Visit {destination.name}?</h2>
          <p className="text-base sm:text-xl mb-6 sm:mb-8 text-blue-100">
            Contact us to customize your perfect {destination.name} experience
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center max-w-2xl mx-auto">
            <a 
              href="https://wa.me/917006840041"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-blue-900 px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-sm sm:text-base hover:bg-gray-100 transition-all shadow-xl flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
              WhatsApp Us
            </a>
            <a 
              href="tel:+917006840041"
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-sm sm:text-base transition-all shadow-xl flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
              Call Now
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
