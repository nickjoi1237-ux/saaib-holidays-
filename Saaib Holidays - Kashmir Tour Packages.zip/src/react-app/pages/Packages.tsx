import { Link } from 'react-router';
import { Clock, MapPin, Star, Calendar, Phone, MessageCircle } from 'lucide-react';

export default function Packages() {
  const packages = [
    {
      name: 'Kashmir Paradise',
      destination: 'Srinagar, Gulmarg, Pahalgam',
      duration: '5 Days / 4 Nights',
      price: '₹15,999',
      rating: 4.8,
      reviews: 120,
      bestFor: 'Couples & Families',
      highlights: ['Dal Lake Shikara', 'Gulmarg Gondola', 'Pahalgam Valley', 'Mughal Gardens'],
      includes: ['Accommodation', 'Breakfast & Dinner', 'All Transfers', 'Sightseeing'],
      slug: 'srinagar',
      gradient: 'from-blue-600 to-blue-800'
    },
    {
      name: 'Honeymoon Special',
      destination: 'Srinagar, Gulmarg, Sonmarg',
      duration: '6 Days / 5 Nights',
      price: '₹22,999',
      rating: 4.9,
      reviews: 95,
      bestFor: 'Honeymooners',
      highlights: ['Houseboat Stay', 'Candlelight Dinner', 'Gulmarg Snow', 'Photography'],
      includes: ['Luxury Hotels', 'All Meals', 'Private Cab', 'Romantic Setups'],
      slug: 'gulmarg',
      gradient: 'from-pink-600 to-rose-600'
    },
    {
      name: 'Adventure Kashmir',
      destination: 'Full Kashmir Valley',
      duration: '7 Days / 6 Nights',
      price: '₹25,999',
      rating: 4.7,
      reviews: 78,
      bestFor: 'Adventure Seekers',
      highlights: ['Trekking', 'Skiing', 'Rafting', 'Mountain Biking'],
      includes: ['Accommodation', 'All Meals', 'Adventure Gear', 'Expert Guides'],
      slug: 'pahalgam',
      gradient: 'from-emerald-600 to-emerald-800'
    },
    {
      name: 'Complete Kashmir',
      destination: 'Srinagar, Gulmarg, Pahalgam, Sonmarg',
      duration: '8 Days / 7 Nights',
      price: '₹28,999',
      rating: 4.9,
      reviews: 150,
      bestFor: 'All Groups',
      highlights: ['Complete Tour', 'All Attractions', 'Shopping Time', 'Local Experiences'],
      includes: ['Deluxe Hotels', 'All Meals', 'Private Vehicle', 'Entry Tickets'],
      slug: 'sonmarg',
      gradient: 'from-blue-700 to-emerald-700'
    },
    {
      name: 'Leh Ladakh Adventure',
      destination: 'Srinagar to Leh via Kargil',
      duration: '10 Days / 9 Nights',
      price: '₹42,999',
      rating: 5.0,
      reviews: 85,
      bestFor: 'Adventure Enthusiasts',
      highlights: ['Pangong Lake', 'Nubra Valley', 'Khardung La', 'Magnetic Hill'],
      includes: ['Accommodation', 'All Meals', '4x4 Vehicle', 'Oxygen Support'],
      slug: 'leh-ladakh',
      gradient: 'from-purple-600 to-blue-800'
    },
    {
      name: 'Budget Kashmir',
      destination: 'Srinagar & Gulmarg',
      duration: '4 Days / 3 Nights',
      price: '₹11,999',
      rating: 4.6,
      reviews: 65,
      bestFor: 'Budget Travelers',
      highlights: ['Dal Lake', 'Gulmarg Day Trip', 'Mughal Gardens', 'Local Market'],
      includes: ['Standard Hotel', 'Breakfast', 'Shared Transfers', 'Sightseeing'],
      slug: 'gulmarg',
      gradient: 'from-amber-600 to-orange-600'
    }
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section with 3D Elements */}
      <section className="relative min-h-[50vh] sm:h-96 flex items-center justify-center overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-blue-700 rounded-full -top-48 -right-48" />
        <div className="shape-3d w-80 h-80 bg-emerald-600 rounded-full -bottom-40 -left-40" />
        
        <div className="absolute inset-0 bg-gradient-to-br from-blue-950/95 via-blue-900/90 to-emerald-950/95 z-10" />
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-3 sm:mb-4">Tour Packages</h1>
          <p className="text-base sm:text-xl text-gray-200">Carefully crafted Kashmir experiences for every traveler</p>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="py-12 sm:py-20 relative">
        <div className="shape-3d w-72 h-72 bg-amber-500 rounded-full top-0 right-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Choose Your Package</h2>
            <p className="text-gray-600 text-sm sm:text-lg">All packages are customizable to your preferences</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
            {packages.map((pkg, index) => (
              <div key={index} className="glass-effect rounded-2xl shadow-xl overflow-hidden card-3d">
                <div className={`relative h-48 sm:h-64 bg-gradient-to-br ${pkg.gradient} flex items-center justify-center text-white p-6`}>
                  <div className="text-center">
                    <h3 className="text-2xl sm:text-3xl font-bold mb-2">{pkg.name}</h3>
                    <p className="text-sm sm:text-base text-white/90">{pkg.bestFor}</p>
                  </div>
                  <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm px-3 sm:px-4 py-1.5 sm:py-2 rounded-full font-bold text-base sm:text-lg shadow-lg">
                    {pkg.price}
                  </div>
                </div>

                <div className="p-4 sm:p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 sm:w-5 sm:h-5 fill-amber-400 text-amber-400" />
                      <span className="font-semibold text-sm sm:text-base">{pkg.rating}</span>
                      <span className="text-gray-500 text-xs sm:text-sm">({pkg.reviews})</span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4 text-gray-600">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-blue-700 flex-shrink-0" />
                      <span className="text-xs sm:text-sm">{pkg.destination}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-emerald-700 flex-shrink-0" />
                      <span className="text-xs sm:text-sm">{pkg.duration}</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <h4 className="font-semibold text-gray-800 mb-2 text-sm sm:text-base">Highlights:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {pkg.highlights.map((highlight, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs sm:text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 bg-gradient-to-r from-blue-700 to-emerald-600 rounded-full flex-shrink-0" />
                          <span>{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4 sm:mb-6">
                    <h4 className="font-semibold text-gray-800 mb-2 text-sm sm:text-base">Includes:</h4>
                    <div className="flex flex-wrap gap-2">
                      {pkg.includes.map((item, i) => (
                        <span key={i} className="bg-blue-50 text-blue-800 px-2 sm:px-3 py-1 rounded-full text-xs font-medium">
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 sm:gap-3">
                    <Link 
                      to={`/destination/${pkg.slug}`}
                      className="text-center bg-gradient-to-r from-blue-700 to-blue-800 text-white py-2.5 sm:py-3 rounded-lg font-semibold hover:from-blue-800 hover:to-blue-900 transition-all text-xs sm:text-sm"
                    >
                      View Details
                    </Link>
                    <a 
                      href="tel:+917006840041"
                      className="text-center bg-gradient-to-r from-emerald-600 to-emerald-700 text-white py-2.5 sm:py-3 rounded-lg font-semibold hover:from-emerald-700 hover:to-emerald-800 transition-all text-xs sm:text-sm"
                    >
                      Call Now
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Custom Package CTA */}
      <section className="py-12 sm:py-20 bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white relative overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-amber-500 rounded-full top-0 right-0" />
        <div className="shape-3d w-80 h-80 bg-blue-700 rounded-full bottom-0 left-0" />
        
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <Calendar className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 sm:mb-6" />
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">Need a Custom Package?</h2>
          <p className="text-base sm:text-xl mb-6 sm:mb-8 text-blue-100">
            Every traveler is unique. Let us create a personalized itinerary based on your interests, budget, and travel dates.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center max-w-2xl mx-auto">
            <a 
              href="tel:+917006840041"
              className="bg-white text-blue-900 px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-sm sm:text-base hover:bg-gray-100 transition-all shadow-xl flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Call for Custom Package
            </a>
            <a 
              href="https://wa.me/917006840041"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-sm sm:text-base transition-all shadow-xl flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
              Chat on WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* What's Included Section */}
      <section className="py-12 sm:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">What's Included</h2>
            <p className="text-gray-600 text-sm sm:text-lg">All packages come with our standard benefits</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {[
              { title: 'Accommodation', description: 'Comfortable hotels or houseboats' },
              { title: 'Transportation', description: 'Private or shared vehicles' },
              { title: 'Sightseeing', description: 'All mentioned attractions' },
              { title: 'Meals', description: 'Breakfast and dinner included' },
              { title: 'Guide Services', description: 'Professional local guides' },
              { title: '24/7 Support', description: 'Round-the-clock assistance' }
            ].map((item, index) => (
              <div key={index} className="glass-effect p-4 sm:p-6 rounded-xl shadow-md text-center card-3d">
                <h3 className="text-lg sm:text-xl font-bold mb-2 text-gray-800">{item.title}</h3>
                <p className="text-gray-600 text-sm sm:text-base">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Contact CTA */}
      <section className="py-12 sm:py-16 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h3 className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-6 text-gray-800">Ready to Book?</h3>
          <p className="text-gray-600 mb-6 sm:mb-8 text-sm sm:text-base">
            Contact us now for instant booking assistance and special offers
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
            <a 
              href="tel:+917006840041"
              className="btn-primary flex items-center justify-center gap-2 text-sm sm:text-base"
            >
              <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
              Call: +91 7006840041
            </a>
            <a 
              href="https://wa.me/917006840041"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary flex items-center justify-center gap-2 text-sm sm:text-base"
            >
              <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
              WhatsApp Now
            </a>
          </div>
          
          <p className="mt-4 text-xs sm:text-sm text-gray-500">
            No advance payment required for inquiry • Free consultation
          </p>
        </div>
      </section>
    </div>
  );
}
