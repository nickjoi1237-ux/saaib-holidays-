import { Phone, MessageCircle, Mail, Award, Heart, Star, MapPin } from 'lucide-react';

export default function Owner() {
  return (
    <div className="overflow-hidden">
      {/* Hero Section with 3D Elements */}
      <section className="relative min-h-[50vh] sm:h-96 flex items-center justify-center overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-blue-700 rounded-full -top-48 -right-48" />
        <div className="shape-3d w-80 h-80 bg-emerald-600 rounded-full -bottom-40 -left-40" />
        
        <div className="absolute inset-0 bg-gradient-to-br from-blue-950/95 via-blue-900/90 to-emerald-950/95 z-10" />
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-3 sm:mb-4">Meet the Owner</h1>
          <p className="text-base sm:text-xl text-gray-200">Your trusted Kashmir travel expert</p>
        </div>
      </section>

      {/* Owner Profile Section */}
      <section className="py-12 sm:py-20 relative">
        <div className="shape-3d w-72 h-72 bg-blue-600 rounded-full top-0 right-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="max-w-5xl mx-auto">
            {/* Owner Card with Photo Placeholder */}
            <div className="glass-effect rounded-3xl shadow-2xl overflow-hidden card-3d">
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 sm:gap-12 p-8 sm:p-12">
                {/* Photo Section - Left Side */}
                <div className="lg:col-span-2">
                  <div className="relative">
                    {/* 3D Photo Frame */}
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-2xl transform rotate-3"></div>
                    <div className="relative rounded-2xl aspect-[3/4] shadow-2xl overflow-hidden">
                      {/* Owner photo */}
                      <img 
                        src="https://mocha-cdn.com/019ad43a-3952-7b8d-b3c5-14ab68e815f2/unnamed.jpg" 
                        alt="Enayat Bhat - Founder of Saaib Holidays"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    {/* Decorative 3D Elements */}
                    <div className="absolute -top-4 -right-4 w-20 h-20 bg-amber-400 rounded-full opacity-20 blur-xl"></div>
                    <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-blue-500 rounded-full opacity-20 blur-xl"></div>
                  </div>
                </div>

                {/* Content Section - Right Side */}
                <div className="lg:col-span-3 space-y-6">
                  <div>
                    <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-2 text-gradient">Mr. Enayat Bhat</h2>
                    <p className="text-lg sm:text-xl text-gray-600 font-medium">Founder & Managing Director</p>
                    <p className="text-sm sm:text-base text-gray-500 mt-1">Saaib Holidays</p>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-full">
                      <Award className="w-4 h-4 text-blue-700" />
                      <span className="text-sm font-medium text-blue-800">10+ Years Experience</span>
                    </div>
                    <div className="flex items-center gap-2 bg-emerald-50 px-4 py-2 rounded-full">
                      <Star className="w-4 h-4 text-emerald-700" />
                      <span className="text-sm font-medium text-emerald-800">5000+ Happy Travelers</span>
                    </div>
                    <div className="flex items-center gap-2 bg-amber-50 px-4 py-2 rounded-full">
                      <MapPin className="w-4 h-4 text-amber-700" />
                      <span className="text-sm font-medium text-amber-800">Kashmir Local Expert</span>
                    </div>
                  </div>

                  <div className="space-y-4 text-gray-700 leading-relaxed text-sm sm:text-base">
                    <p>
                      Welcome to Saaib Holidays! I'm Enayat Bhat, a proud Kashmiri with over a decade of experience in tourism and hospitality. 
                      Born and raised in the beautiful valleys of Kashmir, I have an intimate knowledge of every corner of this paradise on earth.
                    </p>
                    
                    <p>
                      My journey in travel began with a simple passion: sharing the breathtaking beauty and warm hospitality of Kashmir with 
                      travelers from around the world. What started as a dream has now become Saaib Holidays - a trusted name in Kashmir tourism.
                    </p>
                    
                    <p>
                      Unlike generic package tours, I believe in creating <strong>personalized experiences</strong> tailored to each traveler's 
                      unique preferences and interests. Whether you're seeking adventure, romance, family bonding, or spiritual peace, 
                      I personally ensure your Kashmir journey exceeds expectations.
                    </p>
                  </div>

                  {/* Direct Contact CTAs */}
                  <div className="pt-4">
                    <h3 className="font-semibold text-gray-800 mb-3 text-base sm:text-lg">Talk Directly With Me:</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <a 
                        href="tel:+917006840041"
                        className="flex items-center justify-center gap-2 bg-gradient-to-r from-blue-700 to-blue-800 text-white px-6 py-3 rounded-xl font-semibold hover:from-blue-800 hover:to-blue-900 transition-all shadow-lg text-sm sm:text-base"
                      >
                        <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
                        Call Me Now
                      </a>
                      <a 
                        href="https://wa.me/917006840041"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-xl font-semibold hover:from-green-700 hover:to-green-800 transition-all shadow-lg text-sm sm:text-base"
                      >
                        <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                        WhatsApp Me
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* My Mission Section */}
      <section className="py-12 sm:py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="glass-effect rounded-2xl p-8 sm:p-12 card-3d">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Heart className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 text-gradient">My Mission</h2>
                </div>
              </div>
              
              <div className="space-y-4 text-gray-700 leading-relaxed text-sm sm:text-base">
                <p>
                  My mission is simple yet powerful: to showcase Kashmir's unparalleled beauty while providing safe, authentic, 
                  and memorable travel experiences. I don't just sell packages - I craft journeys that touch hearts and create 
                  lifelong memories.
                </p>
                
                <p>
                  Every traveler who contacts me gets my personal attention. I take time to understand your dreams, preferences, 
                  and budget, then design an itinerary that's uniquely yours. From selecting the perfect houseboat on Dal Lake 
                  to arranging a surprise candlelight dinner in Gulmarg's snow-covered meadows - every detail matters.
                </p>
                
                <p className="font-medium text-blue-900 bg-blue-50 p-4 rounded-lg border-l-4 border-blue-700">
                  "I promise you this: when you travel with Saaib Holidays, you're not just a customer - you're family. 
                  Your safety, comfort, and happiness are my personal responsibility." - Enayat Bhat
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Me Section */}
      <section className="py-12 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Why Work With Me?</h2>
            <p className="text-gray-600 text-sm sm:text-lg">What makes Saaib Holidays different</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {[
              {
                icon: MapPin,
                title: 'Local Expertise',
                description: 'Born and raised in Kashmir, I know every hidden gem, best viewpoint, and authentic experience that guidebooks miss.'
              },
              {
                icon: Heart,
                title: 'Personalized Service',
                description: 'I personally design each itinerary. No generic packages - your trip is crafted specifically for you and your interests.'
              },
              {
                icon: Phone,
                title: 'Direct Communication',
                description: 'Call or WhatsApp me anytime. I\'m always available to answer questions, provide advice, or handle emergencies.'
              },
              {
                icon: Award,
                title: 'Proven Track Record',
                description: 'Over 5000 satisfied travelers in 10+ years. My reputation is built on trust, quality, and exceptional service.'
              },
              {
                icon: Star,
                title: 'Fair & Transparent',
                description: 'Honest pricing with no hidden costs. I build relationships, not just transactions. Your satisfaction is my success.'
              },
              {
                icon: MessageCircle,
                title: 'Guidance & Advice',
                description: 'Even if you\'re just exploring options, feel free to call me. I\'m happy to share advice and help you plan - no pressure.'
              }
            ].map((item, index) => (
              <div key={index} className="glass-effect p-6 sm:p-8 rounded-2xl shadow-lg card-3d">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-xl flex items-center justify-center mb-4 transform hover:rotate-12 transition-transform">
                  <item.icon className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-gray-800">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed text-sm sm:text-base">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Personal Message CTA */}
      <section className="py-12 sm:py-20 bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white relative overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-amber-500 rounded-full top-0 right-0" />
        <div className="shape-3d w-80 h-80 bg-blue-700 rounded-full bottom-0 left-0" />
        
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">Let's Plan Your Kashmir Journey Together</h2>
          <p className="text-base sm:text-xl mb-6 sm:mb-8 text-blue-100">
            I'm here to answer all your questions and help create the perfect Kashmir experience for you. 
            Don't hesitate - give me a call or drop a WhatsApp message right now!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center max-w-2xl mx-auto mb-6">
            <a 
              href="tel:+917006840041" 
              className="bg-white text-blue-900 px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-sm sm:text-base hover:bg-gray-100 transition-all shadow-xl flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
              +91 7006840041
            </a>
            <a 
              href="https://wa.me/917006840041"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-sm sm:text-base transition-all shadow-xl flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
              Chat on WhatsApp
            </a>
            <a 
              href="mailto:saaibholidays@gmail.com"
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-sm sm:text-base transition-all shadow-xl flex items-center justify-center gap-2"
            >
              <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
              Email Me
            </a>
          </div>
          
          <p className="text-xs sm:text-sm text-blue-200">
            Available 24/7 • Free Consultation • No Obligation
          </p>
          
          <div className="mt-8 pt-8 border-t border-white/20">
            <p className="text-sm sm:text-base italic">
              "Your dream Kashmir vacation is just one call away. I look forward to serving you!" 
              <span className="block mt-2 font-semibold">- Enayat Bhat</span>
            </p>
          </div>
        </div>
      </section>

      {/* Instagram & Social */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h3 className="text-2xl sm:text-3xl font-bold mb-4 text-gray-800">Follow Our Journey</h3>
          <p className="text-gray-600 mb-6 text-sm sm:text-base">
            See real photos and videos from our travelers on Instagram
          </p>
          <a 
            href="https://instagram.com/saaibholidays"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-pink-600 to-purple-600 text-white px-6 sm:px-8 py-3 rounded-xl font-semibold hover:from-pink-700 hover:to-purple-700 transition-all shadow-lg text-sm sm:text-base"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            @saaibholidays
          </a>
        </div>
      </section>
    </div>
  );
}
