import { Heart, Users, Mountain, Briefcase, Car, Plane, Home, Camera, Utensils, ShieldCheck, Phone, MessageCircle } from 'lucide-react';

export default function Services() {
  const mainServices = [
    {
      icon: Heart,
      title: 'Honeymoon Packages',
      description: 'Romantic getaways designed for couples with luxury stays, candlelight dinners, and stunning locations.',
      features: ['Private Shikara rides', 'Luxury accommodations', 'Romantic dinners', 'Photography sessions'],
      color: 'from-pink-600 to-rose-600'
    },
    {
      icon: Users,
      title: 'Family Tour Packages',
      description: 'Family-friendly tours with comfortable accommodations and activities suitable for all ages.',
      features: ['Kid-friendly activities', 'Spacious rooms', 'Flexible itineraries', 'Safe transportation'],
      color: 'from-blue-600 to-blue-700'
    },
    {
      icon: Mountain,
      title: 'Adventure Tours',
      description: 'Thrilling experiences including trekking, skiing, rafting, and snow activities for adventure enthusiasts.',
      features: ['Professional guides', 'Safety equipment', 'Multiple difficulty levels', 'Scenic locations'],
      color: 'from-emerald-600 to-emerald-700'
    },
    {
      icon: Briefcase,
      title: 'Corporate Tours',
      description: 'Customized packages for corporate teams and large groups with special rates and team activities.',
      features: ['Group discounts', 'Team building', 'Conference facilities', 'Custom itineraries'],
      color: 'from-purple-600 to-purple-700'
    },
    {
      icon: Briefcase,
      title: 'B2B Services',
      description: 'Wholesale rates and dedicated support for travel agents and tour operators.',
      features: ['Competitive rates', 'Reliable service', 'Customization', 'Priority support'],
      color: 'from-amber-600 to-orange-600'
    },
    {
      icon: Car,
      title: 'Car Rental',
      description: 'Well-maintained vehicles with experienced drivers for comfortable travel across Kashmir.',
      features: ['Multiple vehicles', 'Experienced drivers', 'Flexible rentals', 'Affordable rates'],
      color: 'from-blue-700 to-emerald-700'
    }
  ];

  const additionalServices = [
    { icon: Plane, title: 'Airport Transfers', description: 'Pickup and drop services from Srinagar Airport' },
    { icon: Home, title: 'Accommodation', description: 'Best hotels and houseboats at competitive rates' },
    { icon: Camera, title: 'Photography', description: 'Professional photography to capture memories' },
    { icon: Utensils, title: 'Cuisine Tours', description: 'Experience authentic Kashmiri food' },
    { icon: ShieldCheck, title: 'Travel Insurance', description: 'Comprehensive insurance options' },
    { icon: Mountain, title: 'Custom Itineraries', description: 'Personalized trip planning' }
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section with 3D Elements */}
      <section className="relative min-h-[50vh] sm:h-96 flex items-center justify-center overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-blue-700 rounded-full -top-48 -right-48" />
        <div className="shape-3d w-80 h-80 bg-emerald-600 rounded-full -bottom-40 -left-40" />
        
        <div className="absolute inset-0 bg-gradient-to-br from-blue-950/95 via-blue-900/90 to-emerald-950/95 z-10" />
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-3 sm:mb-4">Our Services</h1>
          <p className="text-base sm:text-xl text-gray-200">Complete travel solutions for your Kashmir journey</p>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-12 sm:py-20 relative">
        <div className="shape-3d w-72 h-72 bg-amber-500 rounded-full top-0 right-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Main Services</h2>
            <p className="text-gray-600 text-sm sm:text-lg">Comprehensive packages tailored to your needs</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {mainServices.map((service, index) => (
              <div key={index} className="glass-effect rounded-2xl shadow-lg overflow-hidden card-3d">
                <div className="p-6 sm:p-8">
                  <div className={`w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mb-4 sm:mb-6 transform hover:rotate-12 transition-transform`}>
                    <service.icon className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3 text-gray-800">{service.title}</h3>
                  <p className="text-gray-600 mb-4 sm:mb-6 leading-relaxed text-sm sm:text-base">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2 text-gray-700 text-sm sm:text-base">
                        <div className="w-1.5 h-1.5 bg-gradient-to-r from-blue-700 to-emerald-600 rounded-full flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-12 sm:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Additional Services</h2>
            <p className="text-gray-600 text-sm sm:text-lg">Everything you need for a perfect experience</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {additionalServices.map((service, index) => (
              <div key={index} className="glass-effect p-4 sm:p-6 rounded-xl shadow-md hover:shadow-xl transition-shadow">
                <div className="flex items-start gap-3 sm:gap-4">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <service.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base sm:text-lg font-bold mb-1 sm:mb-2 text-gray-800">{service.title}</h3>
                    <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">{service.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Book With Us - 3D Cards */}
      <section className="py-12 sm:py-20 relative">
        <div className="shape-3d w-80 h-80 bg-blue-600 rounded-full bottom-0 left-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="glass-effect rounded-3xl p-8 sm:p-12 text-center card-3d">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6 sm:mb-8 text-gradient">Why Book With Us?</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-8">
              {[
                { number: '10+', label: 'Years Experience' },
                { number: '5000+', label: 'Happy Clients' },
                { number: '24/7', label: 'Support' },
                { number: '100%', label: 'Satisfaction' }
              ].map((stat, index) => (
                <div key={index} className="p-4 sm:p-6 glass-effect rounded-xl">
                  <div className="text-3xl sm:text-4xl font-bold text-gradient mb-2">{stat.number}</div>
                  <div className="text-xs sm:text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Service Process */}
      <section className="py-12 sm:py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">How It Works</h2>
            <p className="text-gray-600 text-sm sm:text-lg">Simple steps to your perfect Kashmir vacation</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {[
              { step: '01', title: 'Contact Us', description: 'Reach out via phone, email, or WhatsApp' },
              { step: '02', title: 'Plan Together', description: 'Discuss your preferences and budget' },
              { step: '03', title: 'Confirm Booking', description: 'Review itinerary and make payment' },
              { step: '04', title: 'Enjoy Kashmir', description: 'Experience the journey of a lifetime' }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-r from-blue-700 to-emerald-700 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 text-white text-xl sm:text-2xl font-bold shadow-lg">
                  {item.step}
                </div>
                <h3 className="text-lg sm:text-xl font-bold mb-2 text-gray-800">{item.title}</h3>
                <p className="text-gray-600 text-sm sm:text-base">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 sm:py-20 bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white relative overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-amber-500 rounded-full top-0 right-0" />
        
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">Ready to Start Planning?</h2>
          <p className="text-base sm:text-xl text-blue-100 mb-6 sm:mb-8">
            Contact us today for a customized quote
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center max-w-2xl mx-auto">
            <a 
              href="tel:+917006840041"
              className="btn-primary flex items-center justify-center gap-2 text-sm sm:text-base"
            >
              <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
              Call: +91 7006840041
            </a>
            <a 
              href="https://wa.me/917006840041"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary flex items-center justify-center gap-2 text-sm sm:text-base"
            >
              <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
              WhatsApp Us
            </a>
            </div>
          
          <p className="mt-4 sm:mt-6 text-xs sm:text-sm text-blue-200">
            No booking required to inquire • Free consultation available
          </p>
        </div>
      </section>
    </div>
  );
}
