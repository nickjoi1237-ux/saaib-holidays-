import { Award, Heart, Shield, Users, Target, MapPin, Phone } from 'lucide-react';

export default function About() {
  const values = [
    {
      icon: Heart,
      title: 'Passion for Travel',
      description: 'We love Kashmir and are passionate about sharing its beauty with travelers from around the world.'
    },
    {
      icon: Shield,
      title: 'Safety First',
      description: 'Your safety is our priority. We ensure all tours are conducted with highest safety standards.'
    },
    {
      icon: Users,
      title: 'Local Expertise',
      description: 'Our team consists of local experts who know every corner of Kashmir intimately.'
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'We strive for excellence in every aspect of your journey, from planning to execution.'
    }
  ];

  const stats = [
    { number: '10+', label: 'Years Experience' },
    { number: '5000+', label: 'Happy Travelers' },
    { number: '50+', label: 'Tour Packages' },
    { number: '100%', label: 'Satisfaction' }
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section with 3D Elements */}
      <section className="relative min-h-[50vh] sm:h-96 flex items-center justify-center overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-blue-700 rounded-full -top-48 -right-48" />
        <div className="shape-3d w-80 h-80 bg-emerald-600 rounded-full -bottom-40 -left-40" />
        
        <div className="absolute inset-0 bg-gradient-to-br from-blue-950/95 via-blue-900/90 to-emerald-950/95 z-10" />
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-3 sm:mb-4">About Saaib Holidays</h1>
          <p className="text-base sm:text-xl text-gray-200">Your trusted Kashmir travel partner since 2013</p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-12 sm:py-20 relative">
        <div className="shape-3d w-72 h-72 bg-blue-600 rounded-full top-0 right-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4 sm:mb-6">
                <Target className="w-10 h-10 sm:w-12 sm:h-12 text-blue-700" />
                <h2 className="text-3xl sm:text-4xl font-bold text-gradient">Our Mission</h2>
              </div>
              <p className="text-gray-700 text-base sm:text-lg leading-relaxed mb-4 sm:mb-6">
                At Saaib Holidays, our mission is to showcase the unparalleled beauty of Kashmir to travelers worldwide while providing exceptional service, safety, and authentic experiences.
              </p>
              <p className="text-gray-700 text-base sm:text-lg leading-relaxed">
                Based in Srinagar, we are passionate travel professionals dedicated to creating unforgettable memories. With over a decade of experience, we've helped thousands discover the magic of Kashmir.
              </p>
            </div>
            <div className="relative order-first lg:order-last">
              <div className="glass-effect rounded-2xl shadow-2xl p-2 card-3d">
                <div className="aspect-[4/3] bg-gradient-to-br from-blue-700 to-emerald-700 rounded-xl flex items-center justify-center text-white">
                  <div className="text-center p-6">
                    <div className="text-5xl sm:text-6xl font-bold mb-2">10+</div>
                    <div className="text-lg sm:text-xl">Years of Excellence</div>
                    <div className="text-sm text-blue-200 mt-2">Serving Since 2013</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 sm:py-20 bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white relative overflow-hidden">
        <div className="shape-3d w-96 h-96 bg-amber-500 rounded-full top-0 right-0" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center glass-effect p-4 sm:p-6 rounded-xl card-3d">
                <div className="text-4xl sm:text-5xl md:text-6xl font-bold mb-2">{stat.number}</div>
                <div className="text-sm sm:text-base md:text-lg text-blue-100">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-12 sm:py-20 bg-gradient-to-b from-gray-50 to-white relative">
        <div className="shape-3d w-80 h-80 bg-emerald-600 rounded-full bottom-0 left-0 opacity-5" />
        
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Our Core Values</h2>
            <p className="text-gray-600 text-sm sm:text-lg">What makes us different</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {values.map((value, index) => (
              <div key={index} className="glass-effect p-6 sm:p-8 rounded-2xl shadow-lg text-center card-3d">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 transform hover:rotate-12 transition-transform">
                  <value.icon className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-gray-800">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed text-sm sm:text-base">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-12 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Why Choose Us?</h2>
            <p className="text-gray-600 text-sm sm:text-lg">Your perfect Kashmir experience awaits</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
            {[
              {
                icon: MapPin,
                title: 'Local Knowledge',
                description: 'As locals, we have insider knowledge of the best spots, hidden gems, and authentic experiences that most tourists miss.',
                color: 'from-blue-600 to-blue-700'
              },
              {
                icon: Users,
                title: 'Personalized Service',
                description: 'Every traveler is unique. We customize our packages to match your interests, budget, and travel style.',
                color: 'from-emerald-600 to-emerald-700'
              },
              {
                icon: Shield,
                title: 'Safety & Security',
                description: 'We prioritize your safety with experienced guides, verified accommodations, and 24/7 support throughout your journey.',
                color: 'from-blue-700 to-emerald-700'
              },
              {
                icon: Award,
                title: 'Best Value',
                description: 'Competitive pricing without compromising quality. Strong relationships with local vendors for the best rates.',
                color: 'from-amber-600 to-orange-600'
              }
            ].map((item, index) => (
              <div key={index} className="glass-effect p-6 sm:p-8 rounded-2xl shadow-lg card-3d">
                <div className={`w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-r ${item.color} rounded-xl flex items-center justify-center mb-4 sm:mb-6 transform hover:rotate-12 transition-transform`}>
                  <item.icon className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-4 text-gray-800">{item.title}</h3>
                <p className="text-gray-700 leading-relaxed text-sm sm:text-base">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-12 sm:py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-3 sm:mb-4 text-gradient">Meet Our Team</h2>
            <p className="text-gray-600 text-sm sm:text-lg">Passionate professionals dedicated to your journey</p>
          </div>
          
          <div className="glass-effect p-8 sm:p-12 rounded-2xl shadow-xl text-center max-w-3xl mx-auto card-3d">
            <p className="text-base sm:text-xl text-gray-700 leading-relaxed mb-4 sm:mb-6">
              Our team consists of experienced travel professionals, certified tour guides, and local experts who are passionate about Kashmir. We work together to ensure every aspect of your trip is perfect.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mt-6 sm:mt-8">
              <a 
                href="tel:+917006840041" 
                className="btn-primary flex items-center justify-center gap-2 text-sm sm:text-base"
              >
                <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
                Call: +91 7006840041
              </a>
              <a 
                href="https://wa.me/917006840041"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary flex items-center justify-center gap-2 text-sm sm:text-base"
              >
                WhatsApp Us
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
