import { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";
import WhatsAppButton from "@/react-app/components/WhatsAppButton";
import Loader from "@/react-app/components/Loader";
import HomePage from "@/react-app/pages/Home";
import AboutPage from "@/react-app/pages/About";
import OwnerPage from "@/react-app/pages/Owner";
import ServicesPage from "@/react-app/pages/Services";
import PackagesPage from "@/react-app/pages/Packages";
import DestinationPage from "@/react-app/pages/Destination";
import { useScrollBehavior } from "@/react-app/hooks/useScrollBehavior";

function AppContent() {
  const [showLoader, setShowLoader] = useState(true);
  useScrollBehavior();

  useEffect(() => {
    // Hide loader after 2.5 seconds
    const timer = setTimeout(() => {
      setShowLoader(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {showLoader && <Loader />}
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/owner" element={<OwnerPage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/packages" element={<PackagesPage />} />
            <Route path="/destination/:slug" element={<DestinationPage />} />
          </Routes>
        </main>
        <Footer />
        <WhatsAppButton />
      </div>
    </>
  );
}

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
